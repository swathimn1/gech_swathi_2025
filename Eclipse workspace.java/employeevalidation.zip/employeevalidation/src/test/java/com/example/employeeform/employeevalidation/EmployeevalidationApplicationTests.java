package com.example.employeeform.employeevalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeevalidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
