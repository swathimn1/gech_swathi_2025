package com.example.schoolERP.project.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class UserConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    	return http
				.authorizeHttpRequests(auth -> auth.requestMatchers("/", "/about/", "/contact/", "/register/")
						.permitAll().anyRequest().authenticated())
				.formLogin(login -> login.loginPage("/login").loginProcessingUrl("/login")
						.defaultSuccessUrl("/std-details", true).permitAll()).logout(
								logout->logout.logoutSuccessUrl("/login?logout").permitAll())
				.build();
}
}
