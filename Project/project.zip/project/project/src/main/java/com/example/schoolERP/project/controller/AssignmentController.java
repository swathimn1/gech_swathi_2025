package com.example.schoolERP.project.controller;

import com.example.schoolERP.project.model.Assignment;
import com.example.schoolERP.project.service.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/assignments")
public class AssignmentController {

    @Autowired
    private AssignmentService assignmentService;

    @GetMapping
    public String viewAssignments(Model model) {
        List<Assignment> assignments = assignmentService.getAllAssignments();
        model.addAttribute("assignments", assignments);
        return "faculty/assignments/view_assignments"; 
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("assignment", new Assignment());
        return "faculty/assignments/add_assignment";
    }

    @PostMapping("/add")
    public String addAssignment(@ModelAttribute Assignment assignment) {
        assignmentService.saveAssignment(assignment);
        return "redirect:/assignments";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Assignment assignment = assignmentService.getAssignmentById(id);
        model.addAttribute("assignment", assignment);
        return "faculty/assignments/edit_assignment";
    }

    @PostMapping("/update")
    public String updateAssignment(@ModelAttribute Assignment assignment) {
        assignmentService.saveAssignment(assignment);
        return "redirect:/assignments";
    }

    @GetMapping("/delete/{id}")
    public String deleteAssignment(@PathVariable Long id) {
        assignmentService.deleteAssignment(id);
        return "redirect:/assignments";
    }
}
